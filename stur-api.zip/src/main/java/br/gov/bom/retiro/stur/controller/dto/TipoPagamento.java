package br.gov.bom.retiro.stur.controller.dto;

public enum TipoPagamento {

	IPTU, ITR
}
