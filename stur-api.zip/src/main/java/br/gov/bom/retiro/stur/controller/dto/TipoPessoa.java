package br.gov.bom.retiro.stur.controller.dto;

public enum TipoPessoa {

	FISICA, JURIDICA, RURAL
}
