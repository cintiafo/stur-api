package br.gov.bom.retiro.portal;

//@SpringBootTest
class MainTests {

	//@Test
	void contextLoads() {
	}

}
